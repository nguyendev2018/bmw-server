<HTML>
<HEAD>
<TITLE>Convert HTML to Pdf</TITLE>
<link href="assets/css/style.css" type="text/css" rel="stylesheet" />
</HEAD>
<BODY>
	<div id="container">
		<div class="link-container">
			<button class="btn-generate" onclick="convertHTMLToPDF()">Convert HTML to PDF</button>
		</div>
		<div id="html-template">
		<?php require_once __DIR__ . '/Template/html-template.php'; ?>
	</div>
	</div>
</BODY>

<script src="./node_modules/jspdf/dist/jspdf.umd.min.js"></script>
<script type="text/javascript"
	src="./node_modules/html2canvas/dist/html2canvas.js"></script>

<script src="assets/js/convert.js"></script>
</HTML>